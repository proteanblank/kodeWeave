document.addEventListener("DOMContentLoaded", function() {
  // Load library
  var gui = require('nw.gui');

  // Reference to window
  var win = gui.Window.get();

  document.querySelector(".close").onclick = function() {
    window.close();
  };

  document.querySelector(".minimize").onclick = function() {
    win.minimize();
  };

  document.querySelector(".titlebar").addEventListener("dblclick", function() {
    if (win.isMaximized) {
      win.unmaximize();
      win.isMaximized = false;
    } else {
      win.maximize();
    }
  });

  document.querySelector(".maximize").onclick = function() {
    if (win.isMaximized) {
      win.unmaximize();
      win.isMaximized = false;
    } else {
      win.maximize();
    }
  };

  win.on("maximize", function() {
    win.isMaximized = true;
  });
  win.on("unmaximize", function() {
    win.isMaximized = false;
  });
  win.on("enter-fullscreen", function() {
    document.querySelector(".titlebar").classList.toggle('hide');
    document.querySelector("iframe").style.top = 0;
    document.querySelector("iframe").style.height = "100%";
  });
  win.on("leave-fullscreen", function() {
    document.querySelector(".titlebar").classList.toggle('hide');
    document.querySelector("iframe").style.top = 28 + "px";
    document.querySelector("iframe").style.height = window.innerHeight - 28 + "px";
  });
  document.querySelector("iframe").style.height = window.innerHeight - 28 + "px";

  window.addEventListener("keydown", function(e) {
  // Reload App (CMD+R)
    if ( e.metaKey && e.keyCode == 82 ) {
      location.reload(true);
    } else 
  // Hide Mac App (CMD+W)
    if ( e.metaKey && e.keyCode == 87 ) {
      win.hide();
    }
    // else
  // Toggle fullscreen window (CTRL+CMD+F)
    // if ( e.shiftKey && e.metaKey && e.keyCode == 70 ) {
      // win.toggleFullscreen();
    // }
  });

  // Close buttons hides app
  // var hidden = false;
  // gui.App.on('reopen', function(){
  //   hidden = false;
  //   win.show();
  // })

  // win.on('close', function(){
  //   if (hidden == true) {
  //     gui.App.quit();
  //   } else {
  //     win.hide();
  //     hidden = true;
  //   }
  // });

  // Create menu container
  var Menu = new gui.Menu({
    type: 'menubar'
  });

  //initialize default mac menu
  Menu.createMacBuiltin("MyApp");

  // Get the root menu from the default mac menu
  var rootMenu = Menu.items[2].submenu;

  // Append new item to root menu
  rootMenu.insert(
    new gui.MenuItem({
      type: "normal",
      label: 'Toggle Fullscreen',
      key: "F",
      modifiers: "cmd",
      click : function () {
        win.toggleFullscreen();
      }
    })
  );

  rootMenu.insert(
    new gui.MenuItem({
      type: "normal",
      label: 'Reload App',
      key: "R",
      modifiers: "shift-cmd",
      click : function () {
        location.reload(true);
      }
    })
  );

  // Append Menu to Window
  gui.Window.get().menu = Menu;

  // Show app name in titlebar
  document.querySelector("[data-set=appname]").innerHTML = document.title;

  // Responsive UI
  window.addEventListener("resize", function() {
    document.querySelector("iframe").style.height = window.innerHeight - 28 + "px";
  });
});